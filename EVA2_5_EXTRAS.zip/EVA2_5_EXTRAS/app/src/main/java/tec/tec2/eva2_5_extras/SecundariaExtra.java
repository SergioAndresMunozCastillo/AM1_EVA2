package tec.tec2.eva2_5_extras;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SecundariaExtra extends AppCompatActivity {
    Intent inCerrado;
    TextView txtVwMuestraDatos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secundaria_extra);
        txtVwMuestraDatos = findViewById(R.id.txtVwMuestraDatos);
        Intent intent = getIntent();
        txtVwMuestraDatos.setText(intent.getStringExtra("datos"));
    }
    public void cerrar(View v){

    }
}

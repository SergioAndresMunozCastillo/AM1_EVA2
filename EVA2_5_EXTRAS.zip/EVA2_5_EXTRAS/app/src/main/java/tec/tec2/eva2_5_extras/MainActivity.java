package tec.tec2.eva2_5_extras;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Intent inEnvio;
    EditText edTextoDatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edTextoDatos = findViewById(R.id.edTextoDatos);
        inEnvio = new Intent(this, SecundariaExtra.class);
    }
    public void enviarInfo(View v){
        String sMensa = edTextoDatos.getText().toString();
        inEnvio.putExtra("datos", sMensa);
        inEnvio.putExtra("numeros", 100);
        startActivity(inEnvio);
    }
}

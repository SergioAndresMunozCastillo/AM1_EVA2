package com.example.eva2_9_dialogos;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    TextView txt;
    EditText edtName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void clickEstandar(View v){
        new AlertDialog.Builder(this)
                .setTitle("Cuadro de dialogo estandar")
                .setMessage("Hola mundo indiferente!!!")
                .setPositiveButton("OKi",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(getApplicationContext(), "BOTON OK", Toast.LENGTH_LONG).show();
                            }
                        }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getApplicationContext(), "BOTON NO", Toast.LENGTH_LONG).show();
            }
        }).setNeutralButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getApplicationContext(), "BOTON Cancelar", Toast.LENGTH_LONG).show();
            }
        }).create().show();
    }
    public void clickPropio(View v){
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.mi_dialogo);
        //VINCULAR LOS WIDGETS DEL CUADRO DE DIALOGO
        final EditText edtTxtCaptu;
        Button btnOk;
        edtTxtCaptu = dialog.findViewById(R.id.edtName);
        btnOk = dialog.findViewById(R.id.btnOk);
        btnOk.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view) {
                        String sCade = edtTxtCaptu.getText().toString();
                        Toast.makeText(getApplicationContext(), sCade, Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                    }

                }

        );
    }
}
package tec.tec2.eva2_4_activity_stack;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class activity2 extends AppCompatActivity {
    Intent inBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2);
        inBack = new Intent(this, MainActivity.class);
    }
    public void click2(View v){
    //startActivity(inBack);
        //La usamos para destruir la actividad actul (activity2)
        finish();
    }
}
